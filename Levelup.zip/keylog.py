
import pygame

class Game(object):

    def __init__(self, screen):
        self._screen = screen
        self._clock = pygame.time.Clock()

        self.running = False


    def start(self):
        self.running = True

        while self.running:

            dt = self._clock.tick(60)

            for event in pygame.event.get():

                if event.type == pygame.QUIT:
                    self.running = False
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE and self.is_splash() :
                    self.running = False
                if event.type == pygame.KEYDOWN and event.key == pygame.K_F12:
                    self.running = False

                if event.type == pygame.KEYDOWN:
                    print "Pressed key: ", event.key


            pygame.display.flip()


if __name__ == '__main__':
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("Pygame labs")
    game = Game(screen)
    game.start()

