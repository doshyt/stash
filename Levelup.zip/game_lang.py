import os
import pygame
import sys

from core import StageManager, StageType
from stages import Splash, About
from lang_stages import LangChallengeGeneric
from lang_stages.congrats_lang import LangCongratsGeneric


class Game(object):

    def __init__(self, screen, challenge_length=None, max_challenges=0):
        self._screen = screen
        self._clock = pygame.time.Clock()

        self.running = False

        self._stage_manager = StageManager(screen)

        if challenge_length:
            #max_challenges = self.get_number_of_challenges()
            if challenge_length <= max_challenges:
                self._stage_manager.number_of_challenges = challenge_length
            else:
                raise BaseException("Requested number of challenges is larger than "
                                    "the number of the available challenge sources")
        else:
            self._stage_manager.number_of_challenges = max_challenges

        self._stage_manager.max_number_of_challenges = max_challenges

        self._stage_manager.randomize_questions()
        self._stage_manager.add(Splash)
        self._stage_manager.add(About)
        for i in range(self._stage_manager.number_of_challenges):
            self._stage_manager.add(LangChallengeGeneric)
        self._stage_manager.add(LangCongratsGeneric)

    def is_splash(self):
        return self._stage_manager.current_stage_type == StageType.splash_screen

    def start(self):
        self.running = True

        self._stage_manager.start()
        a = 0

        prev_event_generated = pygame.time.get_ticks()
        while self.running:

            dt = self._clock.tick(60)

            # trigger custom event for using with animation
            now = pygame.time.get_ticks()
            if int(now) - int(prev_event_generated) > 50:
                pygame.event.post(pygame.event.Event(pygame.USEREVENT+1, {}))
                prev_event_generated = pygame.time.get_ticks()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE and self.is_splash() :
                    self.running = False
                if event.type == pygame.KEYDOWN and event.key == pygame.K_F12:
                    self.running = False

                if self.running:
                    self._stage_manager.update(event)

            pygame.display.flip()

if __name__ == '__main__':
    pygame.init()
    screen = pygame.display.set_mode((1920, 1080), pygame.FULLSCREEN)
    pygame.display.set_caption("Pygame labs")
    pygame.mouse.set_visible(False)

    # enumerate existing challenges
    max_of_challenges = 0
    for file in os.listdir("lang_challenge"):
        if file.endswith(".answers"):
            max_of_challenges += 1

    if len(sys.argv) > 1:
        challenge_length = int(sys.argv[1])
        game = Game(screen, challenge_length, max_of_challenges)
    else:
        game = Game(screen)
    game.start()

