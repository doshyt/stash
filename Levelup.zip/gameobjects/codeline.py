import pygame

class CodeLine(object):

    def __init__(self, linenumber, code, font, container):

        self.image = font.render("{} - {}".format(linenumber,code), 0, (128, 255, 0))

        self._rect = self.image.get_rect()

        self._direction_x = 1
        self._direction_y = -1 if linenumber % 2 == 0 else 1
        
        top, left, width, height = self._rect

        self._is_large_string = width >= 700

        self._container_rect = container.get_rect()
        self.rect.top = linenumber*50

        self._linenumber = linenumber
        self._code = code


    @property
    def linenumber(self):
        return self._linenumber


    @property
    def text(self):
        return self.image


    @property
    def rect(self):
        return self._rect


    def set_color(self, color):
        self.image = font.render("{} - {}".format(linenumber,code), 0, color)


    def update(self, tick):
        last = self.rect.copy()

        if not self._is_large_string:
            self.rect.left += (150 * tick) * self._direction_x

        self.rect.top += (100 * tick) * self._direction_y

        new = self.rect

        if new.top <= self._container_rect.top:
            new.top = self._container_rect.top
            self._direction_y *= -1
        elif new.bottom >= self._container_rect.bottom:
            new.bottom = self._container_rect.bottom
            self._direction_y *= -1

        if not self._is_large_string:
            if new.right >= self._container_rect.right:
                new.right = self._container_rect.right
                self._direction_x *= -1
            elif new.left <= self._container_rect.left:
                new = self._container_rect.left
                self._direction_x *= -1


