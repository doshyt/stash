import pygame
import os


class CodeResults(pygame.sprite.Sprite):

    def __init__(self, dimensions, position, color, sprite_group, flags=pygame.SRCALPHA):
        super(CodeResults, self).__init__(sprite_group)

        r, b, g = color
        self._bg_color = (r, b, g, 50)
        self._fg_color = color

        self.image = pygame.Surface(dimensions, flags, 32)
        self.rect = self.image.get_rect()

        top, left = position
        self.rect.top = top
        self.rect.left = left

        font_path = os.path.join(os.curdir, "fonts", "Roboto-Regular.ttf")
        self._font = pygame.font.Font(font_path, 36)
 
        self._items = {} 

        self._current_index = 1 


    """
        Reset the code results.
        The data on the surface will be refresh on the next game loop.
    """
    def reset(self):
        self._current_index = 1
        self._items = {}


    """
        item is a tuple containing:
            0 - the scrambled line number
            1 - the correct line number from the unscrambled source code.
            2 - the source code line.
    """
    def additem(self, item):
        self._items[self._current_index] = item         
        self._current_index += 1


    @property
    def items(self):
        return self._items


    def undo(self):
        if len(self._items.keys()) == 0:
            return
        
        self._current_index -= 1
        last_key = self._items.keys()[-1]
        removed_line_number = self._items[last_key][0]

        self._items.pop(last_key)

        return removed_line_number


    """
       Refresh the surface with new data. 
    """
    def _refresh(self):
        self.image.fill(self._bg_color)

        x, y = 10, 10 

        for key in self._items.keys():
            _, _, source_code_line = self._items[key]
            text = self._font.render(source_code_line, 0, self._fg_color)
            self.image.blit(text, (x, y))
            y += 40


    """
        It is called by the sprite group.
    """
    def update(self, time):
        self._refresh()


    """
        It's not necessary to handle any event on this object, it has been
        added to the class only because the parent object call this method
        in every object belonging to the same sprite group.
    """
    def handle_events(self, event):
        pass


