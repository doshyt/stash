import pygame
import os

class Dialog(pygame.sprite.Sprite):

    def __init__(self, image_name, sprite_group):
        super(Dialog, self).__init__(sprite_group)

        image_path = os.path.join(os.curdir, "assets", image_name)
        self.background = pygame.image.load(image_path)
    
        top, left, width, height = self.background.get_rect()
        
        self.image = pygame.Surface((width, height))

        self.rect = self.image.get_rect()

        middle_x = 1920 / 2
        middle_y = 1200 / 2

        top, left, width, height = self.rect

        self.rect.left = middle_x - (width / 2)
        self.rect.top = middle_y - ( height / 2)

        self._visible = False

        self._dialog_message = None

        font_path = os.path.join(os.curdir, "fonts", "Roboto-Bold.ttf")
        self._message_font = pygame.font.Font(font_path, 52)


    def update(self, time):
        self.image.blit(self.background, (0,0))

        if self.dialog_message != None and self.dialog_message != "":
            self.image.blit(self.dialog_message, (950, 190))


    def handle_events(self, event):
        pass


    @property
    def dialog_message(self):
        if self._dialog_message == None: return ""
        text = self._message_font.render(self._dialog_message, 0, (255, 0, 0)) 
        return text


    @dialog_message.setter
    def dialog_message(self, value):
        self._dialog_message = value


    @property
    def visible(self):
        return self._visible


    @visible.setter
    def visible(self, value):
        self._visible = value


class SyntaxErrorDialog(Dialog):
    
    def update(self, time):
        self.image.blit(self.dialog_message, (10, 10))




