import pygame
import os

from core import FileReader, Stage, StageType
from gameobjects import PygameTextBox, CodeResults

from gameobjects import Dialog

from stages import GameOver, StageClear

from time import time
from datetime import timedelta

from core import DataManager

class CodeChallengeBase(Stage):

    def __init__(self, screen, source_code_name):
        super(CodeChallengeBase, self).__init__(screen)

        self._screen = screen

        code_path = os.path.join(os.curdir, "code_challenge", source_code_name)
        self._source_code = FileReader(code_path).get_source()

        self._sprite_group = pygame.sprite.LayeredUpdates()

        self._dialog_sprite_group = pygame.sprite.LayeredUpdates()
        self._exit_sprite_group = pygame.sprite.LayeredUpdates()

        background_path = os.path.join(os.curdir, "assets", "snow_game_backgrounds-d01_002_01.png")
        self._background = pygame.image.load(background_path)
        self._screen.blit(self._background, (0,0))

        font_path = os.path.join(os.curdir, "fonts", "Roboto-Regular.ttf")
        self._source_code_font = pygame.font.Font(font_path, 36)

        font_path = os.path.join(os.curdir, "fonts", "Roboto-Bold.ttf")
        self.font = pygame.font.Font(font_path, 46)

        blue = (47, 177, 211)

        self._number_textbox = PygameTextBox(
                (80, 68),
                (300, 1170),
                blue,
                self._sprite_group,
                focused = True,
                flags = pygame.SRCALPHA,
                only_numbers = True)

        self._code_results = CodeResults((830, 570), (400, 1000), blue, self._sprite_group)

        self._label = self.font.render("Line nr.", 0, blue)

        self._selected = []

        self._render_source_code()

        self._is_correct = False

        self._error_dialog = Dialog("snow_game_dialog-d01-001.png", self._dialog_sprite_group)
        
        self._exit_dialog = Dialog("snow_game_dialog-d01-002.png", self._exit_sprite_group)

        self._close_dialogs = False

        self._tries_left = 3

        self._start_time = time()

        self._stage_name = None

        self._data_manager = DataManager()

        self._elapsed_time = None


    @property
    def stage_name(self):
        return self._stage_name


    @stage_name.setter
    def stage_name(self, value):
        self._stage_name = value


    def _render_source_code(self):
        pos_x, pos_y = (130, 180)

        for key in self._source_code.keys():
            color =  (47, 177, 211) if key not in self._selected else (160, 160, 160)
            text = "[ {} ] - {}".format(key, self._source_code[key][1])
            line = self._source_code_font.render(text, 0, color)
            self._screen.blit(line, (pos_x, pos_y))
            pos_y += 50


    @property
    def type(self):
        return StageType.stage


    def _event_handler(self, event):

        if event.type != pygame.KEYDOWN:
            return

        if not self._is_correct and self._error_dialog.visible:
            self._close_dialogs = True


        if event.key == pygame.K_RETURN:

            if self._number_textbox.get_text() == "":
                return

            typed_value = int(self._number_textbox.get_text())
            self._number_textbox.clear()
            data = self._source_code.get(typed_value)

            if data != None:

                if typed_value in self._selected:
                    return

                source_code_line_number, source_code_line = data
                self._code_results.additem((typed_value, source_code_line_number, source_code_line))
                self._selected.append(typed_value)
                self._render_source_code()

        elif event.key == pygame.K_n and self._exit_dialog.visible:
            self._close_dialogs = True

        elif event.key == pygame.K_y and self._exit_dialog.visible:
            self._completed = True
            self.leave_when_completed = True

        elif event.key == pygame.K_u:
            removed_key = self._code_results.undo()

            if removed_key:
                self._selected.remove(removed_key)

            self._render_source_code()

        elif event.key == pygame.K_z:
            self._selected = []
            self._code_results.reset()
            self._render_source_code()

        elif event.key == pygame.K_ESCAPE and not self._error_dialog.visible:
            self._exit_dialog.visible = True

        elif event.key == pygame.K_r:
            self._run()

            self._tries_left -= 1
            if not self._is_correct:

                if self._tries_left == 0:
                    self.sub_stage = GameOver
                    return
                else:
                    self.sub_stage = None


                self._error_dialog.visible = True
                self._error_dialog.dialog_message = str(self._tries_left)
            else:
                self._end_time = time()
                elapsed_time = self._end_time - self._start_time
                data = {}
                data[self.stage_name] = elapsed_time 
                self._elapsed_time = str(timedelta(seconds=elapsed_time))
                self._data_manager.update_score(data)

                self.sub_stage = StageClear


    def _run(self):
        self._is_correct = False

        total_items_source_code = len(self._source_code.keys())
        total_items_result_code = len(self._code_results.items.keys())

        correct_order = sorted([self._source_code[x][0] for x in self._source_code.keys()])
        result_data = [self._code_results.items[x][1] for x in self._code_results.items.keys()]
    
        results = []

        if total_items_source_code != total_items_result_code:
            self._is_correct = False
            return
        else:
            for index in range(0, len(correct_order)):

                if correct_order[index] == result_data[index]:
                    results.append(True)
                else:
                    results.append(False)

        d = [x for x in results if x == False]
       
        self._is_correct = False if len(d) > 0 else True


    def update(self, event):

        self._event_handler(event)

        if self._close_dialogs and self._error_dialog.visible:
            self._error_dialog.visible = False
            self._close_dialogs = False
            self._dialog_sprite_group.clear(self._screen, self._background)
            self._render_source_code()

        if self._close_dialogs and self._exit_dialog.visible:
            self._exit_dialog.visible = False
            self._close_dialogs = False
            self._exit_sprite_group.clear(self._screen, self._background)
            self._render_source_code()


        for sprite in self._sprite_group.sprites(): sprite.handle_events(event)

        self._screen.blit(self._number_textbox.image, self._number_textbox.rect)

        self._sprite_group.clear(self._screen, self._background)
        self._sprite_group.update(0.123 / 1000.)
        self._sprite_group.draw(self._screen)

        self._screen.blit(self._label, (1000, 300))

        if self._exit_dialog.visible and not self._error_dialog.visible:
            self._exit_sprite_group.update(0.123 / 1000.)
            self._exit_sprite_group.draw(self._screen)

        if self._error_dialog.visible:
            self._dialog_sprite_group.update(0.123 / 1000.)
            self._dialog_sprite_group.draw(self._screen)

