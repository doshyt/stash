import pygame
import os

from core import FileReader
from gameobjects import CodeLine

class ScrambledCode(pygame.sprite.Sprite):

    def __init__(self, dimensions, position, source_code, *sprite_group):
        super(ScrambledCode, self).__init__(*sprite_group)

        self._color = (255, 255, 255, 0)
            
        self._default_font = pygame.font.Font(os.path.join('fonts','Roboto-Regular.ttf'), 38)

        self.image = pygame.Surface(dimensions, pygame.SRCALPHA)

        self.image.fill(self._color)
        
        self.background = self.image.copy() 
        
        self.rect = pygame.rect.Rect((position, dimensions))

        self._source_code = source_code

        self.items = [CodeLine(k, self._source_code[k][1], self._default_font, self.image) 
                      for k in self._source_code.keys()] 

        self._selected = []

    def select_item(self, value):
        self._selected.append(value)

    def unselect_item(self, value):
        self._selected.remove(value)


    def update(self, tick):
     
        self.image.fill(self._color)

        for item in self.items:

            if item.linenumber in self._selected:
                item.set_fg_color((160, 160, 160))

            item.update(tick)
            top, left, width, height = item.rect
            self.image.blit(item.text, (top,left))
        
