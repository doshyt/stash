
class MenuItem(object):

    def __init__(self, text, action):
        self._text = text
        self._action = action

    @property
    def text(self):
        return self._text

    @text.setter
    def text(self, value):
        self._text = value

    @property
    def action(self):
        return self._action

    @action.setter
    def action(self, value):
        self._action = value


