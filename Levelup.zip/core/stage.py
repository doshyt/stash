"""
    Stage base class. It initializes some variables containing the 
    game screen object, default font of the screen and flag to control
    if the stage is finished or not.
"""

import pygame


class Stage(object):

    def __init__(self, screen):
        self.screen = screen
        self.default_font = pygame.font.get_default_font()
        self._font = pygame.font.Font(self.default_font, 16)
        self._completed = False
        self._sub_stage = None
        
        self._retry_when_completed = False
        self._leave_when_completed = False

    @property
    def sub_stage(self):
        return self._sub_stage


    @sub_stage.setter
    def sub_stage(self, value):
        self._sub_stage = value


    @property
    def screen(self):
        return self._screen


    @screen.setter
    def screen(self, value):
        self._screen = value


    """
        Stage event handler.
    """
    def _event_handler(self, event):
        pass


    """
        Update the stage objects.
    """
    def update(self, event):
        pass


    @property
    def retry_when_completed(self):
        return self._retry_when_completed


    @retry_when_completed.setter
    def retry_when_completed(self, value):
        self._retry_when_completed = value


    @property
    def leave_when_completed(self):
        return self._leave_when_completed


    @leave_when_completed.setter
    def leave_when_completed(self, value):
        self._leave_when_completed = value


    """
        Flag indicating if the state is completed.
    """
    def is_complete(self):
        return self._completed


