from gameobjects import LangChallengeBase


class LangChallengeGeneric(LangChallengeBase):

    def __init__(self, screen, challenge_number, q_number, *args):
        super(LangChallengeGeneric, self).__init__(screen,
                                                   source_code_name="lang_challenge_{}.txt".format(challenge_number),
                                                   q_number=q_number)
