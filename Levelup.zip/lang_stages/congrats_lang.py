from gameobjects import LangCongratsBase


class LangCongratsGeneric(LangCongratsBase):
    def __init__(self, screen, number_of_challenges, *args):
        print "numchal1:" + str(number_of_challenges)
        super(LangCongratsGeneric, self).__init__(screen, num_of_challenges=number_of_challenges)
        print "numchal1:" + str(number_of_challenges)
