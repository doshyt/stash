import sys, os
import pygame

from core import Stage, StageType, FileReader
from libs import tmx
from gameobjects import ScrambledCode, Editor
from pygame.sprite import Group

class Hacking(Stage):

    def __init__(self, screen):
        super(Hacking, self).__init__(screen)

        self._screen = screen

        background_path = os.path.join(os.path.abspath(os.curdir), "assets", "fallout_big.jpg")
        self.background = pygame.image.load(background_path)

        map_path = os.path.join('maps', 'empty.tmx')
        self.tilemap = tmx.TileMap.load(map_path, screen.get_size())
        self._sprite_layer = tmx.SpriteLayer()

        self._default_font = pygame.font.Font(os.path.join('fonts','Roboto-Regular.ttf'), 26)

        screen_width = self.screen.get_width()
        screen_height = self.screen.get_height()

        surface_dim = ((screen_width - 200) / 2, screen_height - 280)

        self._source_code = FileReader("oneline.js").get_source()
        
        self.scrambled_code = ScrambledCode(surface_dim, (100, 150), self._source_code, self._sprite_layer)
        self.editor = Editor(surface_dim, (0,0,0))

        self.tilemap.layers.append(self._sprite_layer)

        self.draw_stage()


    @property
    def type(self):
        return StageType.stage


    def update(self, tick):
        self.tilemap.update(tick, self)
        self.draw_stage()
        self.tilemap.set_focus(0, 0)
        self.tilemap.draw(self._screen)

    def update_surfaces(self):
        self.screen.blit(self.scrambled_code.image, (100, 150))
        self.screen.blit(self.editor, (970, 150))


    def draw_stage(self):

        self.screen.blit(self.background, (0, 0))

        #top line
        pygame.draw.line(self.screen, (128, 255, 0),(100,100), (1800, 100))
        # bottom line
        pygame.draw.line(self.screen, (128, 255, 0),(100,1000), (1800, 1000))

        text = self._default_font.render("Snow Term - Version 1.00 (c) Copyright Snow Software AB 2016", 0, (128,255,0))
        self.screen.blit(text, (1065, 50))



    def _event_handler(self, event):
       pass

