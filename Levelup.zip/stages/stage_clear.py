import pygame
import os

from core import Stage, StageType, DataManager


class StageClear(Stage):

    def __init__(self, screen, *args):
        super(StageClear, self).__init__(screen)

        font_path = os.path.join(os.curdir, "fonts", "Roboto-Bold.ttf")
        self._font = pygame.font.Font(font_path, 48)

        result = None

        if len(args) > 0:
            result = args[0]._elapsed_time


        bg_path = os.path.join(os.curdir, "assets", "snow_game_backgrounds-d01_002_05.png")
        bg = pygame.image.load(bg_path)
        screen.blit(bg, (0,0))

        if result != None:
            blue = (47, 177, 211)
            text = self._font.render(result, 0, blue)
            top, left, width, height = screen.get_rect()
            screen.blit(text, ( (width / 2) + 40, 646))  
            



    """
        Hacky property to force the sub_stage move to next stage
        when is set the completed. Dealine is a bitch!!!! :)
    """
    @property
    def move_next_when_completed(self):
        return True


    @property
    def type(self):
        return StageType.sub_stage


    def update(self, event):
        self._event_handler(event)


    def _event_handler(self, event):

        if event.type != pygame.KEYDOWN:
            return

        self._completed = True

