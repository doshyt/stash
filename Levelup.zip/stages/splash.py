import pygame
import os

from core import Stage, StageType
from stages import TopScores

class Splash(Stage):

    def __init__(self, screen, *args):
        super(Splash, self).__init__(screen)
        bg_path = os.path.join(os.curdir, "assets", "snow_game_backgrounds-d01_002_07.png")
        self._background = pygame.image.load(bg_path)
        screen.blit(self._background, (0,0))


    @property
    def type(self):
        return StageType.splash_screen


    def update(self, event):
        self._event_handler(event)


    def _event_handler(self, event):

        if event.type != pygame.KEYDOWN:
            return

        self._completed = True

