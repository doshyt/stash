import pygame
import os

from core import Stage, StageType, DataManager
from gameobjects import PygameTextBox

from validate_email import validate_email

class About(Stage):

    def __init__(self, screen, *args):
        super(About, self).__init__(screen)

        self._screen = screen
        background_path = os.path.join(os.curdir, "assets", "snow_game_backgrounds-d01_002_03.png")
        self.background = pygame.image.load(background_path)

        screen.blit(self.background, (0,0))

        self.group = pygame.sprite.LayeredUpdates()

        blue = (47, 177, 211)
        self.name_textbox = PygameTextBox(
                (920, 70),
                (454, 568),
                blue,
                self.group,
                focused = True,
                flags = pygame.SRCALPHA,
                with_errors = True)

        self.email_textbox = PygameTextBox(
                (920, 70),
                (639, 568),
                blue,
                self.group,
                flags = pygame.SRCALPHA,
                with_errors = True)

        self._data_manager = DataManager(db_name="levelup_lang")


    @property
    def type(self):
        return StageType.registration


    def update(self, event):

        self._event_handler(event)

        for sprite in self.group.sprites(): sprite.handle_events(event)

        self._screen.blit(self.name_textbox.image, self.name_textbox.rect)
        self._screen.blit(self.email_textbox.image, self.email_textbox.rect)

        self.group.clear(self._screen, self.background)
        self.group.update(0.123 / 1000.)
        self.group.draw(self._screen)

    def _validate_fields(self):
        name, email = self.name_textbox.get_text(), self.email_textbox.get_text()
        self.name_textbox.is_valid = len(name) > 0
        self.email_textbox.is_valid = (len(email) > 0 
                                       and validate_email(email) 
                                       and ("." in email.split("@")[1]))


    def _event_handler(self, event):
        if event.type != pygame.KEYDOWN:
            return

        if event.key == pygame.K_ESCAPE:
            self._completed = True
            self.leave_when_completed = True

        if event.type == pygame.KEYDOWN and event.key == pygame.K_UP:
            self.name_textbox.has_focus = True
            self.email_textbox.has_focus = False
        elif event.type == pygame.KEYDOWN and (event.key == pygame.K_DOWN or event.key == pygame.K_TAB):
            self.email_textbox.has_focus = True
            self.name_textbox.has_focus = False

        if event.key == pygame.K_RETURN:
            self._validate_fields()
            if self.name_textbox.is_valid and self.email_textbox.is_valid:
                name, email = self.name_textbox.get_text(), self.email_textbox.get_text()
                player_id = self._data_manager.add_player(name, email)
                print "Added player: ", player_id
                self._completed = True


