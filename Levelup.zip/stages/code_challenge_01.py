from gameobjects import CodeChallengeBase


class CodeChallenge01(CodeChallengeBase):


    def __init__(self, screen, *args):
        super(CodeChallenge01, self).__init__(screen, "python_challenge.py")
        self.stage_name = "challenge_001"
        self._elapsed_time = None


    @property
    def elapsed_time(self):
        return self._elapsed_time
