import pygame
import os
from datetime import timedelta

from core import Stage, StageType, DataManager


class Congrats(Stage):

    def __init__(self, screen, *args):
        super(Congrats, self).__init__(screen)
        
        self._screen = screen

        font_path = os.path.join(os.curdir, "fonts", "Roboto-Bold.ttf")
        self._font = pygame.font.Font(font_path, 48)

        bg_path = os.path.join(os.curdir, "assets", "snow_game_backgrounds-d01_002_06.png")
        bg = pygame.image.load(bg_path)
        screen.blit(bg, (0,0))

        self._data_manager = DataManager()

        current = self._data_manager.get_current()

        blue = (47, 177, 211)
        
        value1 = current["challenge_001"] 
        value2 = current["challenge_002"] 
        value3 = current["challenge_003"] 
        total = (value1 + value2 + value3) / 3
            
        
        challenge_01 = self._font.render(str(timedelta(seconds=value1)), 0, blue)
        challenge_02 = self._font.render(str(timedelta(seconds=value2)), 0, blue)
        challenge_03 = self._font.render(str(timedelta(seconds=value3)), 0, blue)
        total_score = self._font.render(str(timedelta(seconds=total)), 0, blue)
                

        top, left, width, height = self._screen.get_rect()
        w = width / 2
        h = 434

        self._screen.blit(challenge_01, (w, h))
        self._screen.blit(challenge_02, (w, h+100))
        self._screen.blit(challenge_03, (w, h+200))
        self._screen.blit(total_score, (w, h+329))


    @property
    def type(self):
        return StageType.stage

    def update(self, event):
        self._event_handler(event)


    def _event_handler(self, event):

        if event.type != pygame.KEYDOWN:
            return

        if event.key == pygame.K_RETURN:
            self._completed = True
            self.leave_when_completed = True

            

